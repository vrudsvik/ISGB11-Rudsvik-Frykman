<?php

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get('test', function() use ($router) {

    $test = array("works" => true);
    return json_encode($test);
  });
  
  $router->get('movies', 'MovieController@index');
  $router->get('movies/{id}', 'MovieController@read');
  $router->post('movies', 'MovieController@createMovies');
  $router->put('movies/{id}', 'MovieController@updateMovie');
  $router->delete('movies/{id}', 'MovieController@deletemovies');
  
  ?>