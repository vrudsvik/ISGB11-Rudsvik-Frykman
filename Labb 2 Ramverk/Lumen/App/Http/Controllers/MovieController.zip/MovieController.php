<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class MovieController extends Controller{
    
    public function index() {
			
        $movies = Movie::all();
        
        return $movies;
    }
    
    public function read($id) {
        
        $movies = Movie::findOrFail($id);         
        return $movies;
    }
    public function createMovies(Request $request)
    {

        $this->validate($request, [
              
            'title' => 'required|string',
            'year' => 'integer',
            'genre' => 'string',
            'rating' => 'integer'
            
            
            ]);

            Movie::create($request->all());

        //Allt ok, returnera svar
        return ['success' => true];


    }
    
      public function updateMovie(Request $request, $id)
    {
        $movies = Movie::findOrFail($id);

        $data = $this->validate($request, [
                
            'title' => 'required|string',
            'year' => 'integer',
            'genre' => 'string',
            'rating' => 'integer'
            
        ]);

        $movies->fill($data);
        $movies->save();

        //Allt ok, returnera svar
        return ['success' => true];

    }
    
    public function deletemovies($id) {
        
        $movies = Movie::findOrFail($id);
        $movies->delete();
          
        return ['success' => true];

    }





}
?>