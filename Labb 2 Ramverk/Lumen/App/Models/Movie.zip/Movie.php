<?php

    namespace App\Models;

    use Illuminate\Database\Eloquent\Model;
//hämtat och redigerat från Pieres "Bilar"
    class Movie extends Model {
	
        protected $table = 'movies'; // skapar table med namn movies
        protected $fillable = ['id','title','year','genre','rating', ];  // skapar de olika fälten i tabeln
        
    }
    
    
    ?>
    